This is a zip file containing items from Code Quest 2016
put together by Mike Trinka.  The file contains:

- The 2016 welcome packet
- The 2016 problem packet
- Two sets of solution code (MikesCode.zip, HollysCode.zip)
- The example inputs and outputs (ExampleInputs.zip, ExampleOutputs.zip)
- The judging inputs and outputs (JudgingInputs.zip, JudgingOutputs.zip)

If you have any questions, please feel free to contact me at mike.r.trinka@lmco.com.

Thanks for your interest in Code Quest!

-Mike
