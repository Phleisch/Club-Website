import java.util.*;
import java.io.*;

public class Prob01
{
	
	public static void main(String[] args)
	{
		//Scanner in;
		try(Scanner in = new Scanner(new File("Prob01.in.txt")))
		{
			
			int runs = in.nextInt();
			
			while(runs-- > 0)
			{
				
				int names = in.nextInt();
				
				for(int x = 0; x < names; x++)
				{
					String acronym = "";
					String name = in.next()+" "+in.next()+" "+in.next();
					//System.out.println(name);
					String[] parts = name.split(" ");
					//for( String s: parts)
					//	System.out.println(s);
					//System.out.println(parts.length);
					for(int y = 0; y < parts.length; y++)
					{
						acronym = acronym+parts[y].substring(0,1).toUpperCase();
					}
					System.out.println(acronym);
				}
				
			}
			
		}
		catch(FileNotFoundException exception)
		{
			
		}
		
	}
	
}